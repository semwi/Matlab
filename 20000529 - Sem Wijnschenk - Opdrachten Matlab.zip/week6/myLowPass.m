% 2 keer het spectrum.
f = Fs * linspace( 0, 1, ( Lt + 1 ) / 2 ) ;
plot(f, Xss)
xlabel('frequentie (hz)');

% de frequentie verplaatst naar boven de 100 hz
% de symmetrie wordt veroorzaakt doordat in de functie van f verdubbelt

% ik heb ergens een fout gemaakt waardoor ik XIX - XIII niet kan maken

