%maak van het M-bestand een functie
function d=week2SR;
% werking m-files leren in Matlab bij Onderzoeken 2
% mkdir week2

%laat hello world zien
disp("Hello , world!")

% variabelen definieeren
a = 6;
b = 7;
c = a*b;
factor = 2;
d = c*factor;

% laat het antwoord voor d zien
disp (["Het antwoord is", num2str(d)]) 

% schrijf tekst om mensen hun handdoek niet te laten vergeten
tekst = "Vergeet je handdoek niet!";
disp(tekst);