% laad de data uit de f functie.
load("f.mat")

% Maak x variabele.
x = linspace(0, max(f), 100);

% Bereken de standaard diviatie.
sig = std(f);

% Maak het histogram.
h = histogram(f,20);

% Met hold kun je twee functies in een grafiek plotten.
hold on

% Maak de gaussiche verdeling.
y = gaus1d(x, mean(f), 12, sig, 0);
trapz(x,y)

% Plot de gaussiche verdeling
plot(x, y);

% Zet x-as op drie decimalen
xtickformat('%.3f')

% Verander de punten naar komma's
oud_xLabel = get(gca,'XTickLabel');
nieuw_xLabel = strrep(oud_xLabel(:),'.',',');
set(gca,'XTickLabel',nieuw_xLabel)

% Maak de as-labels
xlabel('Meetwaarden uit experiment (nN)')
ylabel('Aantal resultaten (-)')

% Laat een de lijnen zien, zodat de grafiek beter af te lezen is.
grid on

%laat legenda zien
legend('Histogram','Gaussische functie')

